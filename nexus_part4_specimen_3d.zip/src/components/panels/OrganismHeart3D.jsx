import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { VeinCard } from '../ui/VeinCard';
import { Heart } from 'lucide-react';

const SYMBIONT_COLORS = {
  'Coral-Vascular':     0x45D9C4,
  'Mycelial-Neural':    0xB58BFF,
  'Crystalline-Reflex': 0x7DD3FC,
  'Vine-Cognitive':     0x86EFAC,
};

export default function OrganismHeart3D({ host }) {
  const mountRef = useRef(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Dimensions
    const W = container.clientWidth || 220;
    const H = 220;

    // 1. Scene setup
    const scene = new THREE.Scene();
    scene.background = null; // transparent background

    // 2. Camera setup
    const camera = new THREE.PerspectiveCamera(45, W / H, 0.1, 100);
    camera.position.z = 8;

    // 3. Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(W, H);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    // 4. Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const pointLight = new THREE.PointLight(0xffffff, 1.5, 50);
    pointLight.position.set(5, 5, 5);
    scene.add(pointLight);

    // 5. Build dynamic geometry based on taxonomy
    const colorHex = SYMBIONT_COLORS[host.symbiontType] || 0x45D9C4;
    const heartGroup = new THREE.Group();
    scene.add(heartGroup);

    let mainMesh;
    const satellites = [];

    // Coral-Vascular: Pulsing organic bulbous blob cluster
    if (host.symbiontType === 'Coral-Vascular') {
      const geo = new THREE.SphereGeometry(1.4, 32, 32);
      const mat = new THREE.MeshPhongMaterial({
        color: colorHex,
        emissive: 0x112222,
        specular: 0x45D9C4,
        shininess: 40,
        wireframe: true,
      });
      mainMesh = new THREE.Mesh(geo, mat);
      heartGroup.add(mainMesh);

      // Add small side vessels/spheres
      for (let i = 0; i < 4; i++) {
        const satGeo = new THREE.SphereGeometry(0.5, 16, 16);
        const sat = new THREE.Mesh(satGeo, mat);
        const angle = (i / 4) * Math.PI * 2;
        sat.position.set(Math.cos(angle) * 1.5, Math.sin(angle) * 1.5, (Math.random() - 0.5) * 0.5);
        heartGroup.add(sat);
        satellites.push(sat);
      }
    }

    // Mycelial-Neural: Node points network connections
    else if (host.symbiontType === 'Mycelial-Neural') {
      const nodesCount = 18;
      const sphereGeo = new THREE.SphereGeometry(0.12, 8, 8);
      const mat = new THREE.MeshBasicMaterial({ color: colorHex });

      const nodeGroup = new THREE.Group();
      const positions = [];

      for (let i = 0; i < nodesCount; i++) {
        const mesh = new THREE.Mesh(sphereGeo, mat);
        // Distribute points in a spherical/heart-like bounds
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.acos((Math.random() * 2) - 1);
        const r = 1.2 + Math.random() * 0.6;
        mesh.position.set(
          r * Math.sin(phi) * Math.cos(theta),
          r * Math.sin(phi) * Math.sin(theta) * 1.4, // squished vertically
          r * Math.cos(phi)
        );
        nodeGroup.add(mesh);
        satellites.push(mesh);
        positions.push(mesh.position);
      }

      // Draw lines between nearby neural nodes
      const lineMaterial = new THREE.LineBasicMaterial({ color: colorHex, transparent: true, opacity: 0.35 });
      for (let i = 0; i < nodesCount; i++) {
        for (let j = i + 1; j < nodesCount; j++) {
          const dist = positions[i].distanceTo(positions[j]);
          if (dist < 1.6) {
            const lineGeo = new THREE.BufferGeometry().setFromPoints([positions[i], positions[j]]);
            const line = new THREE.Line(lineGeo, lineMaterial);
            nodeGroup.add(line);
          }
        }
      }

      heartGroup.add(nodeGroup);
      mainMesh = nodeGroup;
    }

    // Crystalline-Reflex: Spinning polyhedral prisms
    else if (host.symbiontType === 'Crystalline-Reflex') {
      const geo = new THREE.OctahedronGeometry(1.6, 0);
      const mat = new THREE.MeshPhongMaterial({
        color: colorHex,
        emissive: 0x0a1122,
        specular: 0xffffff,
        shininess: 90,
        flatShading: true,
        wireframe: false,
      });
      mainMesh = new THREE.Mesh(geo, mat);
      heartGroup.add(mainMesh);

      // Outer satellite crystal shards
      for (let i = 0; i < 6; i++) {
        const shardGeo = new THREE.OctahedronGeometry(0.3, 0);
        const shard = new THREE.Mesh(shardGeo, mat);
        const angle = (i / 6) * Math.PI * 2;
        shard.position.set(Math.cos(angle) * 2.2, Math.sin(angle) * 2.2, (Math.random() - 0.5) * 1.0);
        heartGroup.add(shard);
        satellites.push(shard);
      }
    }

    // Vine-Cognitive: Twisting helical tube filaments
    else {
      // Helix spline
      const points = [];
      for (let i = 0; i < 40; i++) {
        const t = i / 40;
        const angle = t * Math.PI * 12;
        points.push(new THREE.Vector3(
          Math.cos(angle) * 1.1,
          (t - 0.5) * 2.8,
          Math.sin(angle) * 1.1
        ));
      }
      const curve = new THREE.CatmullRomCurve3(points);
      const tubeGeo = new THREE.TubeGeometry(curve, 64, 0.14, 8, false);
      const mat = new THREE.MeshPhongMaterial({
        color: colorHex,
        emissive: 0x111e11,
        shininess: 30,
        wireframe: true,
      });

      mainMesh = new THREE.Mesh(tubeGeo, mat);
      heartGroup.add(mainMesh);

      // Central core pulsing sphere
      const coreGeo = new THREE.SphereGeometry(0.8, 16, 16);
      const coreMat = new THREE.MeshPhongMaterial({ color: 0xffaa00, emissive: 0x331100 });
      const core = new THREE.Mesh(coreGeo, coreMat);
      heartGroup.add(core);
      satellites.push(core);
    }

    // 6. Interactive Drag rotation
    let isDragging = false;
    let previousMousePosition = { x: 0, y: 0 };

    const handleMouseDown = () => { isDragging = true; };
    const handleMouseMove = (e) => {
      const deltaMove = {
        x: e.offsetX - previousMousePosition.x,
        y: e.offsetY - previousMousePosition.y,
      };

      if (isDragging) {
        heartGroup.rotation.y += deltaMove.x * 0.01;
        heartGroup.rotation.x += deltaMove.y * 0.01;
      }

      previousMousePosition = {
        x: e.offsetX,
        y: e.offsetY,
      };
    };
    const handleMouseUp = () => { isDragging = false; };

    container.addEventListener('mousedown', handleMouseDown);
    container.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);

    // 7. Animation Loop
    let clock = new THREE.Clock();
    let frameId;

    const animate = () => {
      const time = clock.getElapsedTime();
      
      // Calculate pulse scale based on real-time heartRate
      const hr = host.heartRate || 72;
      const pulseFreq = (hr / 60) * Math.PI * 2; // cycles per second
      
      // Pulsing scale factor (slowing down if host is sedated)
      const baseScale = 1.0;
      const pulseIntensity = host.sedated ? 0.02 : 0.12;
      const currentScale = baseScale + Math.sin(time * pulseFreq) * pulseIntensity;

      if (mainMesh) {
        if (host.symbiontType !== 'Mycelial-Neural') {
          mainMesh.scale.set(currentScale, currentScale, currentScale);
        } else {
          // Pulse individual neural node sizes
          satellites.forEach((sat, idx) => {
            const scaleOffset = Math.sin(time * pulseFreq + idx) * pulseIntensity * 2;
            sat.scale.set(1 + scaleOffset, 1 + scaleOffset, 1 + scaleOffset);
          });
        }
      }

      // Rotate group slowly
      const rotationSpeed = host.status === 'emergence' ? 1.5 : host.status === 'critical' ? 0.8 : 0.3;
      heartGroup.rotation.y += 0.01 * rotationSpeed;
      heartGroup.rotation.z += 0.003 * rotationSpeed;

      // Animate secondary satellites
      satellites.forEach((sat, idx) => {
        if (host.symbiontType === 'Crystalline-Reflex' || host.symbiontType === 'Coral-Vascular') {
          sat.rotation.x += 0.015;
          sat.rotation.y += 0.02;
          // Float back and forth slightly
          sat.position.y += Math.sin(time * 2 + idx) * 0.003;
        }
      });

      renderer.render(scene, camera);
      frameId = requestAnimationFrame(animate);
    };

    animate();

    // Resize observer
    const resizeObserver = new ResizeObserver(entries => {
      for (let entry of entries) {
        const { width, height } = entry.contentRect;
        camera.aspect = width / H;
        camera.updateProjectionMatrix();
        renderer.setSize(width, H);
      }
    });
    resizeObserver.observe(container);

    // Cleanup
    return () => {
      cancelAnimationFrame(frameId);
      resizeObserver.disconnect();
      container.removeEventListener('mousedown', handleMouseDown);
      container.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [host.id, host.symbiontType, host.status, host.sedated, host.heartRate]);

  const colorText = host.status === 'emergence' ? 'text-alert' : host.status === 'critical' ? 'text-critical' : 'text-stable';

  return (
    <VeinCard status={host.status} className="p-6 flex flex-col items-center justify-between" style={{ height: '315px', padding: '24px' }}>
      <div className="flex items-center gap-2 self-start flex-shrink-0 w-full justify-between">
        <div className="flex items-center gap-2">
          <Heart size={14} className={colorText} />
          <span className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase">
            3D WebGL CARDIO-ORGAN MODEL
          </span>
        </div>
        <span className="font-mono text-[8px] text-dim">
          DRAG TO ROTATE
        </span>
      </div>

      {/* WebGL Canvas Container */}
      <div ref={mountRef} className="flex-1 w-full relative flex items-center justify-center bg-black/45 rounded-lg border border-white/5 my-2" style={{ maxHeight: '220px', minHeight: '200px' }}>
        {host.sedated && (
          <div className="absolute top-2 right-2 font-mono text-[8px] text-stable border border-stable/30 bg-stable/10 px-2 py-0.5 rounded compliance-blink">
            FUSION SEDATED // SLOW SYNC
          </div>
        )}
      </div>

      {/* 3D Heart Telemetry Stats */}
      <div className="w-full grid grid-cols-2 gap-2 flex-shrink-0">
        <div className="bg-white/5 rounded px-2 py-1 border border-white/5">
          <div className="font-mono text-[7px] text-dim">CARDIO OUTPUT</div>
          <div className="font-mono text-[10px] font-semibold text-white mt-0.5">
            {host.sedated ? '1.2 L/min [LOW]' : '4.8 L/min [NOMINAL]'}
          </div>
        </div>
        <div className="bg-white/5 rounded px-2 py-1 border border-white/5">
          <div className="font-mono text-[7px] text-dim">ORGAN PULSE</div>
          <div className="font-mono text-[10px] font-semibold text-white mt-0.5">
            {host.sedated ? '32 BPM' : `${host.bioSync[host.bioSync.length - 1]?.heartRate || 72} BPM`}
          </div>
        </div>
      </div>
    </VeinCard>
  );
}
