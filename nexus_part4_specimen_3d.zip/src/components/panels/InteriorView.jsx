import { useRef, useState, useCallback, useEffect } from 'react';
import { X, ZoomIn, ZoomOut, Move, Activity, ShieldAlert, Cpu } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const TYPE_PATH_COLOR = {
  'Coral-Vascular':     '#45D9C4',
  'Mycelial-Neural':    '#B58BFF',
  'Crystalline-Reflex': '#7DD3FC',
  'Vine-Cognitive':     '#86EFAC',
};

export function InteriorView({ host, onClose }) {
  const containerRef = useRef(null);
  const [transform, setTransform] = useState({ x: 0, y: 0, scale: 1 });
  const [probePos, setProbePos] = useState({ x: 210, y: 280 });
  const [activeZone, setActiveZone] = useState('Central Integration Gap');
  const [signalQuality, setSignalQuality] = useState(88.4);
  const dragRef = useRef(null);

  const color = TYPE_PATH_COLOR[host.symbiontType];
  const W = 620, H = 560;

  // Zoom / Pan handlers
  const onMouseDown = useCallback((e) => {
    // If clicking a interactive element, don't initiate pan drag
    if (e.target.closest('.interactive-node')) return;
    dragRef.current = { startX: e.clientX - transform.x, startY: e.clientY - transform.y };
  }, [transform]);

  const onMouseMove = useCallback((e) => {
    if (!dragRef.current) return;
    setTransform(t => ({ ...t, x: e.clientX - dragRef.current.startX, y: e.clientY - dragRef.current.startY }));
  }, []);

  const onMouseUp = useCallback(() => { dragRef.current = null; }, []);

  const zoom = useCallback((dir) => {
    setTransform(t => ({ ...t, scale: Math.max(0.5, Math.min(3.5, t.scale + dir * 0.25)) }));
  }, []);

  const onWheel = useCallback((e) => {
    e.preventDefault();
    zoom(e.deltaY < 0 ? 1 : -1);
  }, [zoom]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, [onWheel]);

  // Handle clicking inside the SVG to place the diagnostic probe
  const handleSvgClick = (e) => {
    const svgEl = e.currentTarget;
    const rect = svgEl.getBoundingClientRect();
    // Get mouse positions relative to SVG
    const clickX = ((e.clientX - rect.left) / rect.width) * W;
    const clickY = ((e.clientY - rect.top) / rect.height) * H;
    setProbePos({ x: Math.round(clickX), y: Math.round(clickY) });

    // Determine zone name dynamically based on X position
    if (clickX < 190) {
      setActiveZone('Host Central Nervous Core');
      setSignalQuality(95.2 + (Math.random() - 0.5) * 4);
    } else if (clickX > 430) {
      setActiveZone('Symbiont Organism Biocore');
      setSignalQuality(host.status === 'emergence' ? 32.1 + Math.random() * 20 : 65.4 + Math.random() * 15);
    } else {
      setActiveZone('Synaptic Fusion Gap');
      setSignalQuality(host.status === 'emergence' ? 12.8 + Math.random() * 25 : 82.3 + Math.random() * 10);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.97 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.97 }}
      transition={{ duration: 0.25 }}
      style={{
        position: 'absolute', inset: 0, zIndex: 50,
        background: 'rgba(5, 10, 14, 0.98)',
        border: '1px solid rgba(69, 217, 196, 0.2)',
        borderRadius: '14px',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
      }}
    >
      {/* ── Advanced Lab Header ── */}
      <div style={{
        padding: '14px 18px', borderBottom: '1px solid rgba(69, 217, 196, 0.15)',
        display: 'flex', alignItems: 'center', gap: '10px', flexShrink: 0,
        background: 'rgba(8, 16, 21, 0.6)',
      }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: '#B58BFF', letterSpacing: '0.12em', fontWeight: 600 }}>
            CEREBROSPINAL DIAGNOSTIC SPECTROSCOPY // GESTATION MONITOR
          </div>
          <div style={{ fontSize: '13px', color: 'var(--color-text)', marginTop: '2px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span>{host.name}</span>
            <span style={{ fontSize: '10px', color: 'var(--color-text-dim)' }}>|</span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: '#45D9C4' }}>{host.symbiontType.toUpperCase()} REPLICATOR</span>
          </div>
        </div>
        <div style={{ display: 'flex', gap: '6px' }}>
          <button onClick={() => zoom(1)} style={{
            background: 'rgba(69, 217, 196, 0.08)', border: '1px solid rgba(69, 217, 196, 0.2)',
            borderRadius: '6px', padding: '5px', color: '#45D9C4', display: 'flex',
          }}><ZoomIn size={14} /></button>
          <button onClick={() => zoom(-1)} style={{
            background: 'rgba(69, 217, 196, 0.08)', border: '1px solid rgba(69, 217, 196, 0.2)',
            borderRadius: '6px', padding: '5px', color: '#45D9C4', display: 'flex',
          }}><ZoomOut size={14} /></button>
          <button onClick={onClose} style={{
            background: 'rgba(239, 68, 68, 0.08)', border: '1px solid rgba(239, 68, 68, 0.2)',
            borderRadius: '6px', padding: '5px', color: '#EF4444', display: 'flex',
          }}><X size={14} /></button>
        </div>
      </div>

      {/* ── Sub-header / Status telemetries ── */}
      <div style={{
        background: 'rgba(8,16,21,0.4)', borderBottom: '1px solid rgba(69,217,196,0.06)',
        padding: '6px 18px', display: 'flex', alignItems: 'center', gap: '18px', flexShrink: 0,
        fontSize: '10px', fontFamily: 'var(--font-mono)', color: 'var(--color-text-muted)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
          <Move size={11} color="#45D9C4" />
          <span>DRAG GRID TO PAN // SCROLL WHEEL TO ZOOM</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '5px', marginLeft: 'auto' }}>
          <Cpu size={11} color="#B58BFF" />
          <span>SELECTED ZONE: <strong style={{ color: '#F2FBFA' }}>{activeZone.toUpperCase()}</strong></span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
          <Activity size={11} color={color} />
          <span>FUSION RESOLUTION: <strong style={{ color: '#F2FBFA' }}>{signalQuality.toFixed(1)}% COHERENCE</strong></span>
        </div>
      </div>

      {/* ── Visual Workspace ── */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden', position: 'relative' }}>
        {/* Left Interactive Probe Telemetry HUD Panel */}
        <div style={{
          width: '180px', borderRight: '1px solid rgba(69, 217, 196, 0.12)',
          background: 'rgba(5, 10, 14, 0.8)', padding: '14px',
          display: 'flex', flexDirection: 'column', gap: '12px', flexShrink: 0,
          zIndex: 10,
        }}>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '8px', color: 'rgba(242,251,250,0.4)', letterSpacing: '0.08em' }}>
            LOCAL PATHOGENIC SCANNER
          </div>

          <div style={{ border: '1px solid rgba(69, 217, 196, 0.15)', borderRadius: '6px', padding: '8px', background: 'black/30' }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '7px', color: 'rgba(242,251,250,0.35)' }}>TARGET COORDS</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', fontWeight: 600, color: '#45D9C4', marginTop: '2px' }}>
              X: {probePos.x} // Y: {probePos.y}
            </div>
          </div>

          <div style={{ border: '1px solid rgba(69, 217, 196, 0.15)', borderRadius: '6px', padding: '8px', background: 'black/30' }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '7px', color: 'rgba(242, 251, 250, 0.35)' }}>MEMBRANE POTENTIAL</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', fontWeight: 600, color: '#F2FBFA', marginTop: '2px' }}>
              {(120 - Math.abs(probePos.x - 200) * 0.25).toFixed(1)} mV
            </div>
          </div>

          <div style={{ border: '1px solid rgba(69, 217, 196, 0.15)', borderRadius: '6px', padding: '8px', background: 'black/30' }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '7px', color: 'rgba(242, 251, 250, 0.35)' }}>NEURO-TRANSMISSION</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', fontWeight: 600, color: color, marginTop: '2px' }}>
              {(800 - Math.abs(probePos.y - 250) * 1.5).toFixed(0)} Hz
            </div>
          </div>

          {host.status === 'emergence' && (
            <div style={{
              border: '1px solid rgba(181, 139, 255, 0.3)', borderRadius: '6px', padding: '8px',
              background: 'rgba(181, 139, 255, 0.05)', display: 'flex', flexDirection: 'column', gap: '3px',
              animation: 'compliance-blink 2s ease-in-out infinite'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '4px', fontFamily: 'var(--font-mono)', fontSize: '8px', color: '#B58BFF', fontWeight: 'bold' }}>
                <ShieldAlert size={10} /> DETECTED EMERGENCE
              </div>
              <div style={{ fontSize: '9px', color: 'rgba(242,251,250,0.7)', lineHeight: 1.2 }}>
                Instability threshold exceeded in fusion cortex.
              </div>
            </div>
          )}

          {/* Micro Wave Oscilloscope Graph */}
          <div style={{ marginTop: 'auto', borderTop: '1px solid rgba(69, 217, 196, 0.1)', paddingTop: '10px' }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '7px', color: 'rgba(242,251,250,0.3)', marginBottom: '4px' }}>
              WAVEFORM ANALYZER
            </div>
            <svg width="100%" height="45" style={{ background: 'rgba(0,0,0,0.3)', borderRadius: '4px', overflow: 'hidden' }}>
              <path
                d={`M 0,22 Q 20,${10 + Math.sin(Date.now() * 0.005) * 15} 40,22 T 80,22 T 120,22 T 160,22`}
                fill="none" stroke="#45D9C4" strokeWidth="1.2"
              />
            </svg>
          </div>
        </div>

        {/* Viewport for pan/zoom */}
        <div
          ref={containerRef}
          onMouseDown={onMouseDown}
          onMouseMove={onMouseMove}
          onMouseUp={onMouseUp}
          onMouseLeave={onMouseUp}
          style={{ flex: 1, overflow: 'hidden', cursor: 'grab', position: 'relative', userSelect: 'none' }}
        >
          <div style={{
            transform: `translate(${transform.x}px, ${transform.y}px) scale(${transform.scale})`,
            transformOrigin: 'center center',
            width: '100%', height: '100%',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            transition: 'transform 0.05s linear',
          }}>
            <svg
              viewBox={`0 0 ${W} ${H}`}
              width={W} height={H}
              onClick={handleSvgClick}
              style={{ overflow: 'visible' }}
            >
              <defs>
                <filter id={`g-glow-${host.id}`}>
                  <feGaussianBlur stdDeviation="5" result="blur" />
                  <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
                </filter>
                {/* Horizontal Grid Pattern Overlay */}
                <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                  <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(69, 217, 196, 0.03)" strokeWidth="0.8"/>
                </pattern>
              </defs>

              {/* Grid Background */}
              <rect width={W} height={H} fill="url(#grid)" />

              {/* Zone Dividers */}
              <line x1="190" y1="0" x2="190" y2={H} stroke="rgba(69, 217, 196, 0.07)" strokeWidth="1" strokeDasharray="3 4" />
              <line x1="430" y1="0" x2="430" y2={H} stroke="rgba(69, 217, 196, 0.07)" strokeWidth="1" strokeDasharray="3 4" />

              {/* Zone Labels */}
              <text x="15" y="25" fontFamily="var(--font-mono)" fontSize="8" fill="rgba(242,251,250,0.25)">CNS SPINE MATRIX [COLUMN-A]</text>
              <text x="205" y="25" fontFamily="var(--font-mono)" fontSize="8" fill="rgba(242,251,250,0.25)">SYNAPSE INTEGRATION INTERFACE [COLUMN-B]</text>
              <text x="445" y="25" fontFamily="var(--font-mono)" fontSize="8" fill="rgba(242,251,250,0.25)">SYMBIONT BIO-CORE [COLUMN-C]</text>

              {/* ========================================================
                  COLUMN A: HOST CENTRAL NERVOUS MATRIX
                  ======================================================== */}
              <g id="host-cns">
                {/* Central Spinal Cord Segment */}
                <rect x="75" y="40" width="30" height="480" rx="6" fill="rgba(69, 217, 196, 0.02)" stroke="rgba(69, 217, 196, 0.12)" strokeWidth="1" />
                
                {/* Internal Spinal Cord Vertebrae Blocks */}
                {[70, 140, 210, 280, 350, 420, 490].map((y, i) => (
                  <g key={i}>
                    <rect x="80" y={y - 15} width="20" height="30" rx="3" fill="rgba(69, 217, 196, 0.05)" stroke="rgba(69, 217, 196, 0.25)" strokeWidth="1" />
                    <line x1="80" y1={y} x2="100" y2={y} stroke="rgba(69, 217, 196, 0.15)" strokeWidth="0.8" />
                  </g>
                ))}

                {/* Host CNS Nodes (Synapses) */}
                {[100, 180, 260, 340, 420].map((y, i) => (
                  <g key={i}>
                    <circle cx="90" cy={y} r="5" fill="#45D9C4" filter={`url(#g-glow-${host.id})`} />
                    {/* Lateral nerve roots exiting spinal cord */}
                    <path d={`M 90,${y} C 120,${y - 15} 140,${y} 190,${y + 10}`} fill="none" stroke="rgba(69, 217, 196, 0.4)" strokeWidth="1.5" />
                    <path d={`M 90,${y} C 120,${y + 20} 150,${y + 5} 190,${y + 35}`} fill="none" stroke="rgba(69, 217, 196, 0.2)" strokeWidth="1" />
                  </g>
                ))}
              </g>

              {/* ========================================================
                  COLUMN B: SYNAPSE INTEGRATION GAP (Flowing signals)
                  ======================================================== */}
              <g id="synapse-gap">
                {/* Moving Synapse Signal Particles */}
                {/* Path 1 */}
                <path id="path1" d="M 190,110 C 270,110 350,140 430,160" fill="none" stroke="none" />
                {/* Path 2 */}
                <path id="path2" d="M 190,190 C 290,170 310,250 430,220" fill="none" stroke="none" />
                {/* Path 3 */}
                <path id="path3" d="M 190,270 C 250,290 380,260 430,340" fill="none" stroke="none" />
                {/* Path 4 */}
                <path id="path4" d="M 190,375 C 310,340 310,430 430,400" fill="none" stroke="none" />
                {/* Path 5 */}
                <path id="path5" d="M 190,455 C 260,490 350,430 430,470" fill="none" stroke="none" />

                {/* Draw the visual paths */}
                {[1, 2, 3, 4, 5].map((idx) => (
                  <use key={idx} href={`#path${idx}`} stroke="rgba(242,251,250,0.06)" strokeWidth="2.5" fill="none" />
                ))}

                {/* Animated Particles flowing across the paths */}
                {[1, 2, 3, 4, 5].map((idx) => {
                  const pColor = host.status === 'emergence' ? '#B58BFF' : '#45D9C4';
                  const dur = `${2 + idx * 0.4}s`;
                  return (
                    <g key={idx}>
                      {/* Synaptic bubble 1 */}
                      <circle r="4" fill={pColor} filter={`url(#g-glow-${host.id})`}>
                        <animateMotion dur={dur} repeatCount="indefinite" rotate="auto">
                          <mpath href={`#path${idx}`} />
                        </animateMotion>
                      </circle>
                      {/* Secondary trailing particle */}
                      <circle r="2" fill="#F2FBFA" opacity="0.6">
                        <animateMotion dur={dur} repeatCount="indefinite" rotate="auto" begin="0.8s">
                          <mpath href={`#path${idx}`} />
                        </animateMotion>
                      </circle>
                    </g>
                  );
                })}
              </g>

              {/* ========================================================
                  COLUMN C: SYMBIONT ORGANISM BIO-CORE
                  ======================================================== */}
              <g id="symbiont-core" transform="translate(430, 0)">
                {/* Intertwining Organic Veins */}
                <path
                  d="M 0,160 C 80,180 120,80 160,110 C 130,220 80,240 160,280 C 100,320 120,420 160,400 T 160,470"
                  fill="none" stroke={color} strokeWidth="2" strokeOpacity="0.4"
                  filter={`url(#g-glow-${host.id})`}
                />

                {/* Symbiont Nuclei nodes */}
                {[110, 160, 220, 280, 340, 400, 470].map((y, i) => {
                  const nodeStable = host.status === 'stable' ? true : Math.sin(y) > 0;
                  const nodeCol = nodeStable ? color : '#B58BFF';
                  return (
                    <g key={i} transform={`translate(${80 + Math.sin(y * 0.05) * 35}, ${y})`}>
                      <circle r="8" fill={`${nodeCol}18`} stroke={nodeCol} strokeWidth="1.5" />
                      <circle r="3" fill={nodeCol} />
                      <line x1={-80} y1={0} x2={0} y2={0} stroke={`${nodeCol}33`} strokeWidth="0.8" strokeDasharray="3 2" />
                      <text x="12" y="3" fontFamily="var(--font-mono)" fontSize="7" fill="rgba(242,251,250,0.4)">SYM-N.{i}</text>
                    </g>
                  );
                })}
              </g>

              {/* ========================================================
                  DIAGNOSTIC TARGETING SCOPE PROBE HUD (Click to place)
                  ======================================================= */}
              <g transform={`translate(${probePos.x}, ${probePos.y})`} style={{ pointerEvents: 'none' }}>
                {/* Crosshairs */}
                <circle r="22" fill="none" stroke="#45D9C4" strokeWidth="0.8" strokeDasharray="4 2" />
                <circle r="32" fill="none" stroke="#45D9C4" strokeWidth="0.5" opacity="0.4" />
                <circle r="2.5" fill="#45D9C4" filter={`url(#g-glow-${host.id})`} />

                {/* Laser scanline projection */}
                <line x1="-45" y1="0" x2="45" y2="0" stroke="#45D9C4" strokeWidth="0.5" opacity="0.6" />
                <line x1="0" y1="-45" x2="0" y2="45" stroke="#45D9C4" strokeWidth="0.5" opacity="0.6" />

                {/* Floating Coordinates Box */}
                <g transform="translate(15, -45)">
                  <rect x="-3" y="-12" width="112" height="18" rx="3" fill="rgba(5, 10, 14, 0.9)" stroke="#45D9C4" strokeWidth="0.8" />
                  <text x="4" y="0" fontFamily="var(--font-mono)" fontSize="7" fill="#45D9C4" fontWeight="bold">PROBE ACTIVE // SCANNING</text>
                </g>
              </g>
            </svg>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
