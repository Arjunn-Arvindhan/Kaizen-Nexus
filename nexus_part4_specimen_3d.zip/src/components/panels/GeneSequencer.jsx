import { useEffect, useState } from 'react';
import { VeinCard } from '../ui/VeinCard';
import { Dna } from 'lucide-react';

const SYMBIONT_COLORS = {
  'Coral-Vascular':     '#45D9C4',
  'Mycelial-Neural':    '#B58BFF',
  'Crystalline-Reflex': '#7DD3FC',
  'Vine-Cognitive':     '#86EFAC',
};

export default function GeneSequencer({ host }) {
  const [helixOffset, setHelixOffset] = useState(0);
  const color = SYMBIONT_COLORS[host.symbiontType] || '#45D9C4';

  useEffect(() => {
    let animId;
    const animate = () => {
      setHelixOffset(prev => (prev + 0.04) % (Math.PI * 2));
      animId = requestAnimationFrame(animate);
    };
    animate();
    return () => cancelAnimationFrame(animId);
  }, []);

  // Generate helix node points
  const nodes = 14;
  const points = [];
  const W = 360, H = 80;

  for (let i = 0; i < nodes; i++) {
    const x = 30 + (i / (nodes - 1)) * (W - 60);
    const angle = (i * 0.7) + helixOffset;
    const y1 = H / 2 + Math.sin(angle) * 22;
    const y2 = H / 2 - Math.sin(angle) * 22;
    const alpha = (Math.cos(angle) + 1.2) / 2.2; // depth-based opacity
    points.push({ x, y1, y2, alpha });
  }

  return (
    <VeinCard status={host.status} className="p-6 flex flex-col justify-between" style={{ height: '170px', padding: '24px' }}>
      <div className="flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-2">
          <Dna size={14} color={color} />
          <span className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase">
            NUCLEOTIDE SEQUENCE LOG // DOUBLE HELIX
          </span>
        </div>
        <span className="font-mono text-[8px] text-dim">
          SEQ COHERENCE: {(92.4 - (host.status === 'emergence' ? 15 : host.status === 'critical' ? 24 : 0)).toFixed(1)}%
        </span>
      </div>

      {/* Animated Helix Area */}
      <div className="flex-1 flex items-center justify-center bg-black/30 rounded-lg border border-white/5 my-2 overflow-hidden">
        <svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`} style={{ overflow: 'visible' }}>
          {/* Middle bridge connector line */}
          <line x1="20" y1={H/2} x2={W-20} y2={H/2} stroke="rgba(255,255,255,0.03)" strokeWidth="1" strokeDasharray="3 4" />

          {/* Duplex connections */}
          {points.map((pt, idx) => (
            <line
              key={`line-${idx}`}
              x1={pt.x} y1={pt.y1}
              x2={pt.x} y2={pt.y2}
              stroke={color}
              strokeWidth="1.2"
              strokeOpacity={pt.alpha * 0.28}
            />
          ))}

          {/* Helix Strand A */}
          {points.map((pt, idx) => (
            <circle
              key={`sa-${idx}`}
              cx={pt.x} cy={pt.y1}
              r={3.5 + pt.alpha * 1.5}
              fill={color}
              opacity={pt.alpha * 0.9}
              style={{ filter: `drop-shadow(0 0 4px ${color}88)` }}
            />
          ))}

          {/* Helix Strand B */}
          {points.map((pt, idx) => (
            <circle
              key={`sb-${idx}`}
              cx={pt.x} cy={pt.y2}
              r={3.5 + (1 - pt.alpha) * 1.5}
              fill={host.status === 'emergence' ? '#F2FBFA' : '#B58BFF'}
              opacity={(1 - pt.alpha) * 0.9}
            />
          ))}
        </svg>
      </div>

      {/* Genome readings metrics */}
      <div className="grid grid-cols-3 gap-2 flex-shrink-0">
        {[
          { label: 'CODON STABILITY', val: host.status === 'emergence' ? 'FLUCTUATING' : 'SECURE' },
          { label: 'TRANSCRIPTION', val: (host.status === 'emergence' ? 142 : host.status === 'critical' ? 72 : 98) + ' Hz' },
          { label: 'MUTATION SCAN', val: host.status === 'emergence' ? 'EMERGENT' : 'STABLE' },
        ].map((item, i) => (
          <div key={i} className="bg-white/5 rounded p-1.5 border border-white/5 text-center">
            <div className="font-mono text-[7px] text-dim">{item.label}</div>
            <div className="font-mono text-[10px] font-semibold text-white mt-0.5">{item.val}</div>
          </div>
        ))}
      </div>
    </VeinCard>
  );
}
