import { useState } from 'react';
import OrganismSpecimen3D from './OrganismSpecimen3D';
import { VeinCard } from '../ui/VeinCard';
import { FlaskConical, ShieldAlert, Cpu, Eye } from 'lucide-react';
import { motion } from 'framer-motion';

const STATUS_THEMES = {
  stable:    { border: 'rgba(69,217,196,0.3)',  color: '#45D9C4', label: 'STABLE' },
  watch:     { border: 'rgba(245,158,11,0.3)',  color: '#F59E0B', label: 'WATCH' },
  emergence: { border: 'rgba(181,139,255,0.4)', color: '#B58BFF', label: 'EMERGENCE' },
  critical:  { border: 'rgba(239,68,68,0.4)',   color: '#EF4444', label: 'CRITICAL' },
};

const FAMILY_LABELS = {
  'Coral-Vascular':     'CORAL-V',
  'Mycelial-Neural':    'MYCEL-N',
  'Crystalline-Reflex': 'CRYST-R',
  'Vine-Cognitive':     'VINE-C',
};

export default function IncubationLabVault3D({ host, hosts = [], onSelect }) {
  const [chamberDrained, setChamberDrained] = useState(false);

  const selectedHost = host || hosts[0];
  const activeTheme = STATUS_THEMES[selectedHost.status] || STATUS_THEMES.stable;

  return (
    <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      
      {/* ── Dashboard Tab Header ── */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px', flexShrink: 0 }}>
        <div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: '#B58BFF', letterSpacing: '0.12em', fontWeight: 600 }}>
            INCUBATION VAULT OVERWATCH // CHAMBER TELEMETRY FEED
          </div>
          <div style={{ fontSize: '14px', color: '#F2FBFA', marginTop: '2px', fontWeight: 600 }}>
            25 Gestating Specimen Pods Exposing Morphology Anomalies
          </div>
        </div>
      </div>

      {/* ── Main Dual-Pane Workspace ── */}
      <div style={{ flex: 1, display: 'flex', gap: '20px', minHeight: 0, overflow: 'hidden' }}>
        
        {/* Left Side: Scrollable Organism Gallery List */}
        <div style={{
          width: '280px', flexShrink: 0, display: 'flex', flexDirection: 'column',
          background: 'rgba(8,16,21,0.5)', border: '1px solid rgba(69,217,196,0.1)',
          borderRadius: '12px', overflow: 'hidden',
        }}>
          {/* List Title */}
          <div style={{
            padding: '12px 14px', borderBottom: '1px solid rgba(69,217,196,0.1)',
            display: 'flex', alignItems: 'center', gap: '8px',
          }}>
            <FlaskConical size={13} color="#45D9C4" />
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'rgba(242,251,250,0.5)', letterSpacing: '0.08em' }}>
              INCUBATION REGISTRY
            </span>
          </div>

          {/* Roster entries */}
          <div style={{ flex: 1, overflowY: 'auto', padding: '8px' }}>
            {hosts.map((h, idx) => {
              const isSelected = h.id === selectedHost.id;
              const theme = STATUS_THEMES[h.status];
              return (
                <div
                  key={h.id}
                  onClick={() => onSelect(h.id)}
                  style={{
                    display: 'flex', alignItems: 'center', gap: '10px',
                    padding: '8px 10px', borderRadius: '8px', marginBottom: '4px',
                    cursor: 'pointer',
                    background: isSelected ? 'rgba(69,217,196,0.08)' : 'transparent',
                    border: `1px solid ${isSelected ? theme.color + '44' : 'transparent'}`,
                    transition: 'all 0.15s',
                  }}
                  onMouseEnter={(e) => { if (!isSelected) e.currentTarget.style.background = 'rgba(255,255,255,0.02)'; }}
                  onMouseLeave={(e) => { if (!isSelected) e.currentTarget.style.background = 'transparent'; }}
                >
                  {/* Number Badge */}
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'rgba(242,251,250,0.3)', width: '16px' }}>
                    {(idx + 1).toString().padStart(2, '0')}
                  </span>

                  {/* Name and Family */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: '12px', fontWeight: 500, color: '#F2FBFA', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {h.name}
                    </div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: '8px', color: 'rgba(242,251,250,0.4)' }}>
                      {FAMILY_LABELS[h.symbiontType]}
                    </div>
                  </div>

                  {/* Status Tier Badge */}
                  <span style={{
                    fontFamily: 'var(--font-mono)', fontSize: '8px', fontWeight: 600,
                    color: theme.color, border: `1px solid ${theme.color}25`,
                    background: `${theme.color}08`, borderRadius: '4px', padding: '2px 6px',
                  }}>
                    {theme.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Side: WebGL focused 3D specimen pod */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
          
          <VeinCard status={selectedHost.status} style={{ flex: 1, display: 'flex', flexDirection: 'column', position: 'relative', padding: 0 }}>
            {/* Critical compliance lockdown overlay */}
            {selectedHost.lockdown && (
              <div style={{
                position: 'absolute', inset: 0, zIndex: 100,
                background: 'rgba(239, 68, 68, 0.15)',
                backdropFilter: 'blur(6px)',
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                border: '2px solid #EF4444',
                padding: '24px',
              }}>
                <ShieldAlert size={32} color="#EF4444" style={{ marginBottom: '10px' }} />
                <h4 style={{ fontFamily: 'var(--font-mono)', fontSize: '14px', fontWeight: 600, color: '#EF4444' }}>
                  SPECIMEN VAULT LOCKED
                </h4>
                <p style={{ fontSize: '11px', color: 'rgba(242,251,250,0.8)', textAlign: 'center', marginTop: '4px', maxWidth: '280px' }}>
                  Surgical extraction process engaged. Gestation sensor streams are suspended.
                </p>
              </div>
            )}

            {/* Chamber 3D canvas viewport */}
            <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>
              <OrganismSpecimen3D host={selectedHost} width={600} height={400} />

              {/* 3D Telemetry Overlay HUD (Click focused camera display) */}
              <div style={{
                position: 'absolute', top: '16px', left: '16px',
                fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'rgba(242,251,250,0.5)',
                display: 'flex', flexDirection: 'column', gap: '3px', pointerEvents: 'none',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <Cpu size={12} color={activeTheme.color} />
                  <span>ACTIVE OBSERVATION // POD-{selectedHost.id.toUpperCase()}</span>
                </div>
                <div style={{ fontSize: '13px', fontWeight: 600, color: '#F2FBFA', marginTop: '4px' }}>
                  SPECIMEN: {selectedHost.name.toUpperCase()}
                </div>
                <div style={{ display: 'flex', gap: '8px', marginTop: '2px' }}>
                  <span>MORPHOLOGY: <strong style={{ color: activeTheme.color }}>{FAMILY_LABELS[selectedHost.symbiontType]}</strong></span>
                  <span>STATUS: <strong style={{ color: activeTheme.color }}>{activeTheme.label}</strong></span>
                </div>
              </div>

              <div style={{
                position: 'absolute', bottom: '16px', right: '16px',
                fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'rgba(242,251,250,0.4)',
                textAlign: 'right', pointerEvents: 'none',
              }}>
                <div>GESTATION RATE: {selectedHost.status === 'emergence' ? 'FORMING' : '100%'}</div>
                <div>INTEGRITY: {selectedHost.fusionIntegrity}%</div>
              </div>
            </div>

            {/* Chamber operation controls bar */}
            <div style={{
              padding: '14px 16px', background: 'rgba(8,16,21,0.6)',
              borderTop: '1px solid rgba(69,217,196,0.1)',
              display: 'flex', alignItems: 'center', justify: 'space-between', gap: '16px',
            }}>
              <div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'rgba(242,251,250,0.4)' }}>CHAMBER ENVIRONMENT</div>
                <div style={{ fontSize: '12px', color: '#F2FBFA', marginTop: '2px' }}>
                  Fluid density: {chamberDrained ? 'VACUUM' : 'NOMINAL'} // Target temp: 37.0°C
                </div>
              </div>

              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => setChamberDrained(!chamberDrained)}
                style={{
                  background: 'rgba(69,217,196,0.08)',
                  border: '1px solid rgba(69,217,196,0.25)',
                  color: '#45D9C4', padding: '6px 14px', borderRadius: '6px',
                  fontFamily: 'var(--font-mono)', fontSize: '10px', fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                {chamberDrained ? 'REFRESH GESTATION MATRIX' : 'DEPRESSURIZE GESTATION TANK'}
              </motion.button>
            </div>
          </VeinCard>

        </div>

      </div>

    </div>
  );
}
