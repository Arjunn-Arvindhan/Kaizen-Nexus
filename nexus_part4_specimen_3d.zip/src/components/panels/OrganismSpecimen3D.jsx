import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

// Color definitions (varying lightness/saturation by tier)
const TIER_COLORS = {
  'Coral-Vascular': {
    stable:    0xff7a59, // Bright Coral
    watch:     0xdc5636, // Saturated Coral/Red
    emergence: 0xffa085, // Pale Coral
    critical:  0x9c3d26, // Desaturated Dark Coral
  },
  'Mycelial-Neural': {
    stable:    0x45d9c4, // Bright Teal
    watch:     0x2ea595, // Saturated Teal
    emergence: 0x8df2e4, // Pale Teal
    critical:  0x1e655c, // Desaturated Dark Teal
  },
  'Vine-Cognitive': {
    stable:    0x86efac, // Bright Green
    watch:     0x4ade80, // Saturated Green
    emergence: 0xbbf7d0, // Pale Green
    critical:  0x166534, // Desaturated Dark Green
  },
  'Crystalline-Reflex': {
    stable:    0xb58bff, // Bright Purple
    watch:     0x8b5cf6, // Saturated Purple
    emergence: 0xddd6fe, // Pale Purple
    critical:  0x5b21b6, // Desaturated Dark Purple
  },
};

// Deterministic name hash generator
function getNameHash(name) {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  return Math.abs(hash);
}

// Pseudo-random number generator from seed
function seedRandom(seed) {
  const x = Math.sin(seed++) * 10000;
  return x - Math.floor(x);
}

export default function OrganismSpecimen3D({ host, width = 360, height = 300 }) {
  const mountRef = useRef(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Scene & Camera
    const scene = new THREE.Scene();
    scene.background = null;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0, 8);

    // 2. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    // 3. OrbitControls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.enableZoom = true;
    controls.maxDistance = 15;
    controls.minDistance = 3;

    // 4. Lighting Rig
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.55);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight1.position.set(5, 10, 5);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0xffffff, 0.4);
    dirLight2.position.set(-5, -5, 5);
    scene.add(dirLight2);

    // 5. Seed-based parameters
    const seed = getNameHash(host.name);
    const rnd = () => seedRandom(seed + Math.random());

    // Color tier mapping
    const familyColor = TIER_COLORS[host.symbiontType]?.[host.status] || 0x45d9c4;

    // Geometry parameters based on Status Tier
    const isEmergence = host.status === 'emergence';
    const isCritical = host.status === 'critical';
    const isWatch = host.status === 'watch';

    const scaleFactor = isEmergence ? 0.5 : isWatch ? 0.85 : isCritical ? 0.75 : 1.0;
    const noiseAmplitude = isCritical ? 0.25 : isWatch ? 0.08 : 0.0;

    // Materials
    const material = new THREE.MeshPhongMaterial({
      color: familyColor,
      emissive: 0x0c1220,
      specular: 0xffffff,
      shininess: host.symbiontType === 'Crystalline-Reflex' ? 90 : 35,
      flatShading: host.symbiontType === 'Crystalline-Reflex', // low poly facets
      transparent: true,
      opacity: isCritical ? 0.85 : 1.0,
      wireframe: host.symbiontType !== 'Crystalline-Reflex' && host.symbiontType !== 'Coral-Vascular',
    });

    const specimenGroup = new THREE.Group();
    specimenGroup.scale.set(scaleFactor, scaleFactor, scaleFactor);
    scene.add(specimenGroup);

    // Array to keep track of dynamic vertex deforming meshes
    const deformingMeshes = [];

    // ── Build Morphology Families ──

    // A. CORAL-V: Branching upward-fanning L-system structure
    if (host.symbiontType === 'Coral-Vascular') {
      const branchCount = isEmergence ? 3 : 7;
      const fanAngle = 0.55;

      for (let i = 0; i < branchCount; i++) {
        const points = [];
        const baseAngle = ((i / (branchCount - 1)) - 0.5) * Math.PI * fanAngle;
        const length = 2.2 + seedRandom(seed + i) * 0.8;

        for (let j = 0; j < 8; j++) {
          const t = j / 7;
          // fan upwards and outwards with deterministic bend
          const curveX = Math.sin(baseAngle) * length * t;
          const curveY = Math.cos(baseAngle) * length * t - 1.0;
          const curveZ = Math.sin(t * Math.PI + seedRandom(seed + i)) * 0.2;
          points.push(new THREE.Vector3(curveX, curveY, curveZ));
        }

        const curve = new THREE.CatmullRomCurve3(points);
        const segments = isEmergence ? 8 : 24;
        const tubeGeo = new THREE.TubeGeometry(curve, segments, 0.12 * (1.2 - i*0.04), 8, false);
        const branchMesh = new THREE.Mesh(tubeGeo, material);
        specimenGroup.add(branchMesh);
        deformingMeshes.push(branchMesh);
      }
    }

    // B. MYCEL-N: Thread-like interconnected mesh radiating from central node
    else if (host.symbiontType === 'Mycelial-Neural') {
      const nodeCount = isEmergence ? 8 : 22;
      const points = [];
      const nodeGeo = new THREE.SphereGeometry(0.08, 8, 8);
      const nodeMat = new THREE.MeshBasicMaterial({ color: familyColor });

      // Generate random node positions inside sphere boundary
      for (let i = 0; i < nodeCount; i++) {
        const r = 1.0 + seedRandom(seed + i) * 0.8;
        const theta = seedRandom(seed + i + 1) * Math.PI * 2;
        const phi = Math.acos((seedRandom(seed + i + 2) * 2) - 1);
        
        const pos = new THREE.Vector3(
          r * Math.sin(phi) * Math.cos(theta),
          r * Math.sin(phi) * Math.sin(theta) * 1.2,
          r * Math.cos(phi)
        );
        points.push(pos);

        // Render node sphere
        const sphere = new THREE.Mesh(nodeGeo, nodeMat);
        sphere.position.copy(pos);
        specimenGroup.add(sphere);
      }

      // Connect nearby nodes with thin tubes
      const maxDist = isEmergence ? 1.6 : 1.35;
      for (let i = 0; i < nodeCount; i++) {
        for (let j = i + 1; j < nodeCount; j++) {
          const dist = points[i].distanceTo(points[j]);
          if (dist < maxDist) {
            const lineCurve = new THREE.CatmullRomCurve3([points[i], points[j]]);
            const tubeGeo = new THREE.TubeGeometry(lineCurve, 4, 0.03, 4, false);
            const connectionMesh = new THREE.Mesh(tubeGeo, material);
            specimenGroup.add(connectionMesh);
            deformingMeshes.push(connectionMesh);
          }
        }
      }
    }

    // C. VINE-C: Elongated twisting helical spline TubeGeometry
    else if (host.symbiontType === 'Vine-Cognitive') {
      const splinePoints = [];
      const turns = isEmergence ? 5 : 12;
      const segments = isEmergence ? 32 : 128;
      
      for (let i = 0; i < segments; i++) {
        const t = i / segments;
        const angle = t * Math.PI * turns + (seedRandom(seed) * Math.PI);
        splinePoints.push(new THREE.Vector3(
          Math.cos(angle) * 0.85 * (1 - t * 0.3),
          (t - 0.5) * 3.4,
          Math.sin(angle) * 0.85 * (1 - t * 0.3)
        ));
      }

      const curve = new THREE.CatmullRomCurve3(splinePoints);
      const tubeGeo = new THREE.TubeGeometry(curve, segments, 0.1, 8, false);
      const vineMesh = new THREE.Mesh(tubeGeo, material);
      specimenGroup.add(vineMesh);
      deformingMeshes.push(vineMesh);
    }

    // D. CRYST-R: Faceted, low-poly angular octahedrons/icosahedrons
    else {
      const crystalCount = isEmergence ? 3 : 7;
      const crystalMat = new THREE.MeshPhongMaterial({
        color: familyColor,
        emissive: 0x050812,
        specular: 0xffffff,
        shininess: 95,
        flatShading: true, // No smooth shading
        transparent: true,
        opacity: isCritical ? 0.8 : 1.0,
      });

      for (let i = 0; i < crystalCount; i++) {
        const polyGeo = new THREE.OctahedronGeometry(0.65 + seedRandom(seed + i) * 0.35, 0);
        const polyMesh = new THREE.Mesh(polyGeo, crystalMat);
        
        // Arrange crystals in a geometric stacked structure
        const angle = (i / crystalCount) * Math.PI * 2;
        polyMesh.position.set(
          Math.cos(angle) * 0.8,
          (i - (crystalCount - 1)/2) * 0.65,
          Math.sin(angle) * 0.8
        );
        polyMesh.rotation.set(seedRandom(seed + i) * 3, seedRandom(seed + i + 1) * 3, 0);
        specimenGroup.add(polyMesh);
        // Crystalline does not get continuous deforming wave noise, but gets critical rotation jitter
        deformingMeshes.push(polyMesh);
      }
    }

    // Capture initial buffer positions for noise offset calculations
    const positionBackups = deformingMeshes.map(m => {
      const posAttr = m.geometry.attributes.position;
      return posAttr ? posAttr.array.slice() : null;
    });

    // 6. Animation Loop
    let clock = new THREE.Clock();
    let frameId;

    const animate = () => {
      const time = clock.getElapsedTime();

      // Slow specimen rotation
      specimenGroup.rotation.y += 0.005;

      // Apply Shape Modifiers based on Status Tier in the render loop
      if (isCritical) {
        // Flickering opacity
        material.opacity = 0.6 + Math.sin(time * 15) * 0.25;
        // Jittering rotation
        specimenGroup.rotation.x = Math.sin(time * 24) * 0.05;
        specimenGroup.rotation.z = Math.cos(time * 20) * 0.05;
      }

      // Deforming vertex noise (for WATCH and CRITICAL)
      if ((isWatch || isCritical) && host.symbiontType !== 'Crystalline-Reflex') {
        deformingMeshes.forEach((mesh, meshIdx) => {
          const originalPositions = positionBackups[meshIdx];
          const posAttr = mesh.geometry.attributes.position;
          if (!posAttr || !originalPositions) return;

          const arr = posAttr.array;
          const len = arr.length;
          
          const amp = isCritical ? 0.24 : 0.06;
          const freq = isCritical ? 8.5 : 2.5;

          for (let i = 0; i < len; i += 3) {
            const x = originalPositions[i];
            const y = originalPositions[i + 1];
            const z = originalPositions[i + 2];

            // Wave noise displacement formula using coordinates and name seed hash
            const offset = Math.sin(y * 3 + time * freq + seed) * Math.cos(x * 3 + time * freq) * amp;
            
            arr[i] = x + offset;
            arr[i + 1] = y + offset;
            arr[i + 2] = z + offset;
          }
          posAttr.needsUpdate = true;
        });
      }

      controls.update();
      renderer.render(scene, camera);
      frameId = requestAnimationFrame(animate);
    };

    animate();

    // Resize container observer
    const resizeObserver = new ResizeObserver(entries => {
      for (let entry of entries) {
        const { width: newW, height: newH } = entry.contentRect;
        camera.aspect = newW / newH;
        camera.updateProjectionMatrix();
        renderer.setSize(newW, newH);
      }
    });
    resizeObserver.observe(container);

    // Cleanup WebGL and OrbitControls
    return () => {
      cancelAnimationFrame(frameId);
      resizeObserver.disconnect();
      controls.dispose();
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      // dispose geometry/materials
      specimenGroup.traverse(child => {
        if (child.isMesh) {
          child.geometry.dispose();
          if (Array.isArray(child.material)) {
            child.material.forEach(m => m.dispose());
          } else {
            child.material.dispose();
          }
        }
      });
    };
  }, [host.id, host.status, host.symbiontType, host.name, width, height]);

  return <div ref={mountRef} className="w-full h-full" />;
}
