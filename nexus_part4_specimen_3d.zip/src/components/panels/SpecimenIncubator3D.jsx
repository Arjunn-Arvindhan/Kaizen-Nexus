import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { VeinCard } from '../ui/VeinCard';
import { FlaskConical } from 'lucide-react';

const SYMBIONT_COLORS = {
  'Coral-Vascular':     0x45D9C4,
  'Mycelial-Neural':    0xB58BFF,
  'Crystalline-Reflex': 0x7DD3FC,
  'Vine-Cognitive':     0x86EFAC,
};

export default function SpecimenIncubator3D({ host }) {
  const mountRef = useRef(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Dimensions
    const W = container.clientWidth || 220;
    const H = 220;

    // 1. Scene Setup
    const scene = new THREE.Scene();
    scene.background = null;

    // 2. Camera Setup
    const camera = new THREE.PerspectiveCamera(45, W / H, 0.1, 100);
    camera.position.z = 8;

    // 3. Renderer Setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(W, H);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    // 4. Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.65);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight.position.set(0, 8, 4);
    scene.add(dirLight);

    // 5. Specimen Group
    const creatureGroup = new THREE.Group();
    scene.add(creatureGroup);

    const colorHex = SYMBIONT_COLORS[host.symbiontType] || 0x45D9C4;
    const material = new THREE.MeshPhongMaterial({
      color: colorHex,
      emissive: 0x101a2c,
      specular: 0xffffff,
      shininess: 40,
      wireframe: true,
    });

    const branches = []; // Keep references to animate sway

    // Procedural Creature Gestation geometries
    if (host.symbiontType === 'Coral-Vascular') {
      // Branching coral fan tentacles
      const branchCount = 6;
      for (let i = 0; i < branchCount; i++) {
        const points = [];
        const baseAngle = (i / branchCount) * Math.PI * 2;
        const length = 2.0 + Math.random() * 0.8;
        
        for (let j = 0; j < 8; j++) {
          const t = j / 7;
          points.push(new THREE.Vector3(
            Math.cos(baseAngle) * 0.6 * (1 + t * 0.8),
            (t - 0.5) * length,
            Math.sin(baseAngle) * 0.6 * (1 + t * 0.8)
          ));
        }

        const curve = new THREE.CatmullRomCurve3(points);
        const tubeGeo = new THREE.TubeGeometry(curve, 16, 0.08, 6, false);
        const tube = new THREE.Mesh(tubeGeo, material);
        creatureGroup.add(tube);
        branches.push({ mesh: tube, baseAngle, length });
      }
    }

    else if (host.symbiontType === 'Mycelial-Neural') {
      // Fractal Neural Dendrite system
      const dendriteGroup = new THREE.Group();
      const nodeGeo = new THREE.SphereGeometry(0.08, 8, 8);
      const nodeMat = new THREE.MeshBasicMaterial({ color: colorHex });

      const points = [];
      const createBranch = (start, length, angleX, angleY, depth) => {
        if (depth > 3) return;

        const end = new THREE.Vector3(
          start.x + Math.sin(angleX) * Math.cos(angleY) * length,
          start.y + Math.sin(angleX) * Math.sin(angleY) * length,
          start.z + Math.cos(angleX) * length
        );

        // Draw bone segment
        const lineGeo = new THREE.BufferGeometry().setFromPoints([start, end]);
        const lineMat = new THREE.LineBasicMaterial({ color: colorHex, transparent: true, opacity: 0.7 - depth * 0.15 });
        const line = new THREE.Line(lineGeo, lineMat);
        dendriteGroup.add(line);

        // Draw node sphere
        const node = new THREE.Mesh(nodeGeo, nodeMat);
        node.position.copy(end);
        dendriteGroup.add(node);
        branches.push({ mesh: node, type: 'node', start: start.clone(), depth });

        // Branch off
        createBranch(end, length * 0.75, angleX + 0.5, angleY + 1.2, depth + 1);
        createBranch(end, length * 0.75, angleX - 0.5, angleY - 1.2, depth + 1);
      };

      // Create primary trunk roots
      createBranch(new THREE.Vector3(0, -1.2, 0), 1.2, 0.4, 0, 1);
      createBranch(new THREE.Vector3(0, -1.2, 0), 1.2, -0.4, Math.PI, 1);
      createBranch(new THREE.Vector3(0, -1.2, 0), 1.2, 0, Math.PI / 2, 1);

      creatureGroup.add(dendriteGroup);
    }

    else if (host.symbiontType === 'Crystalline-Reflex') {
      // Spinning geometric crystal clusters
      const crystalMat = new THREE.MeshPhongMaterial({
        color: colorHex,
        emissive: 0x050d22,
        specular: 0xffffff,
        shininess: 80,
        flatShading: true,
      });

      const clusterGroup = new THREE.Group();
      
      // Central crystal node
      const centerGeo = new THREE.IcosahedronGeometry(1.0, 0);
      const centerMesh = new THREE.Mesh(centerGeo, crystalMat);
      clusterGroup.add(centerMesh);

      // Branching outer crystal shards
      const shardCount = 8;
      for (let i = 0; i < shardCount; i++) {
        const shardGeo = new THREE.ConeGeometry(0.35, 1.2, 4);
        const shard = new THREE.Mesh(shardGeo, crystalMat);
        
        const theta = (i / shardCount) * Math.PI * 2;
        shard.position.set(Math.cos(theta) * 1.6, Math.sin(theta) * 0.4, Math.sin(theta) * 1.6);
        shard.rotation.set(Math.random() * 2, Math.random() * 2, theta);
        
        clusterGroup.add(shard);
        branches.push({ mesh: shard, theta });
      }

      creatureGroup.add(clusterGroup);
    }

    else {
      // Vine-Cognitive: Twisting spiral vine double helix climbing up
      const splinePointsA = [];
      const splinePointsB = [];
      const turns = 10;
      
      for (let i = 0; i < 40; i++) {
        const t = i / 40;
        const angle = t * Math.PI * turns;
        splinePointsA.push(new THREE.Vector3(
          Math.cos(angle) * 0.9,
          (t - 0.5) * 2.8,
          Math.sin(angle) * 0.9
        ));
        splinePointsB.push(new THREE.Vector3(
          Math.cos(angle + Math.PI) * 0.9,
          (t - 0.5) * 2.8,
          Math.sin(angle + Math.PI) * 0.9
        ));
      }

      const curveA = new THREE.CatmullRomCurve3(splinePointsA);
      const curveB = new THREE.CatmullRomCurve3(splinePointsB);
      
      const vineA = new THREE.Mesh(new THREE.TubeGeometry(curveA, 64, 0.08, 6, false), material);
      const vineB = new THREE.Mesh(new THREE.TubeGeometry(curveB, 64, 0.08, 6, false), material);
      
      creatureGroup.add(vineA);
      creatureGroup.add(vineB);

      // Add inter-strand bridging rungs
      const rungMat = new THREE.MeshBasicMaterial({ color: 0xffaa00, transparent: true, opacity: 0.6 });
      for (let i = 2; i < 38; i += 2) {
        const ptA = splinePointsA[i];
        const ptB = splinePointsB[i];
        const rungCurve = new THREE.CatmullRomCurve3([ptA, ptB]);
        const rung = new THREE.Mesh(new THREE.TubeGeometry(rungCurve, 4, 0.03, 4, false), rungMat);
        creatureGroup.add(rung);
      }
    }

    // 6. Incubation bubbles particle field
    const bubbleCount = 30;
    const bubbleGeo = new THREE.SphereGeometry(0.04, 4, 4);
    const bubbleMat = new THREE.MeshBasicMaterial({ color: 0x45D9C4, transparent: true, opacity: 0.4 });
    const bubbles = [];

    for (let i = 0; i < bubbleCount; i++) {
      const bubble = new THREE.Mesh(bubbleGeo, bubbleMat);
      bubble.position.set(
        (Math.random() - 0.5) * 2.5,
        (Math.random() - 0.5) * 3.0,
        (Math.random() - 0.5) * 2.5
      );
      scene.add(bubble);
      bubbles.push(bubble);
    }

    // 7. Drag Interaction
    let isDragging = false;
    let prevMousePos = { x: 0, y: 0 };

    const handleMouseDown = () => { isDragging = true; };
    const handleMouseMove = (e) => {
      const dx = e.offsetX - prevMousePos.x;
      const dy = e.offsetY - prevMousePos.y;
      if (isDragging) {
        creatureGroup.rotation.y += dx * 0.01;
        creatureGroup.rotation.x += dy * 0.01;
      }
      prevMousePos = { x: e.offsetX, y: e.offsetY };
    };
    const handleMouseUp = () => { isDragging = false; };

    container.addEventListener('mousedown', handleMouseDown);
    container.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);

    // 8. Animation loop
    let clock = new THREE.Clock();
    let frameId;

    const animate = () => {
      const time = clock.getElapsedTime();
      const speedFactor = host.status === 'emergence' ? 2.5 : host.status === 'critical' ? 1.4 : 0.6;

      // Rotate model
      creatureGroup.rotation.y += 0.006 * speedFactor;

      // Procedural sway animations based on taxonomy
      if (host.symbiontType === 'Coral-Vascular') {
        branches.forEach((b, idx) => {
          b.mesh.rotation.z = Math.sin(time * 1.5 + idx) * 0.08 * speedFactor;
          b.mesh.rotation.x = Math.cos(time * 1.2 + idx) * 0.05 * speedFactor;
        });
      } 
      
      else if (host.symbiontType === 'Mycelial-Neural') {
        branches.forEach((b, idx) => {
          if (b.type === 'node') {
            b.mesh.position.y += Math.sin(time * 2.2 + idx) * 0.0015 * speedFactor;
          }
        });
      }

      else if (host.symbiontType === 'Crystalline-Reflex') {
        branches.forEach((b, idx) => {
          // Orbit shard crystals slightly
          b.mesh.position.y += Math.sin(time * 1.8 + idx) * 0.003 * speedFactor;
          b.mesh.rotation.y += 0.01 * speedFactor;
        });
      }

      // Animate rise of bubbles
      bubbles.forEach(b => {
        b.position.y += 0.018 * speedFactor;
        // reset if top is reached
        if (b.position.y > 2.0) {
          b.position.y = -2.0;
          b.position.x = (Math.random() - 0.5) * 2.5;
        }
      });

      renderer.render(scene, camera);
      frameId = requestAnimationFrame(animate);
    };

    animate();

    // Resize observer
    const resizeObserver = new ResizeObserver(entries => {
      for (let entry of entries) {
        const { width } = entry.contentRect;
        camera.aspect = width / H;
        camera.updateProjectionMatrix();
        renderer.setSize(width, H);
      }
    });
    resizeObserver.observe(container);

    // Cleanup
    return () => {
      cancelAnimationFrame(frameId);
      resizeObserver.disconnect();
      container.removeEventListener('mousedown', handleMouseDown);
      container.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [host.id, host.symbiontType, host.status]);

  const primaryCol = host.status === 'emergence' ? 'text-alert' : host.status === 'critical' ? 'text-critical' : 'text-stable';

  return (
    <VeinCard status={host.status} className="p-6 flex flex-col items-center justify-between" style={{ height: '315px', padding: '24px' }}>
      <div className="flex items-center justify-between w-full flex-shrink-0">
        <div className="flex items-center gap-2">
          <FlaskConical size={14} className={primaryCol} />
          <span className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase">
            3D POST-INCUBATION SPECIES MODEL
          </span>
        </div>
        <span className="font-mono text-[8px] text-dim">
          GESTATION: 100%
        </span>
      </div>

      {/* WebGL Canvas Viewport */}
      <div ref={mountRef} className="flex-1 w-full relative flex items-center justify-center bg-black/45 rounded-lg border border-white/5 my-2" style={{ maxHeight: '220px', minHeight: '200px' }}>
        {/* Futuristic chamber overlay marks */}
        <div className="absolute inset-x-2 top-2 flex justify-between font-mono text-[6px] text-dim pointer-events-none">
          <span>POD_LOCK: AUTH</span>
          <span>CELL_COHERENCE: NOMINAL</span>
        </div>
      </div>

      {/* Telemetries footer */}
      <div className="w-full grid grid-cols-2 gap-2 flex-shrink-0">
        <div className="bg-white/5 rounded px-2 py-1 border border-white/5">
          <div className="font-mono text-[7px] text-dim">GESTATION LEVEL</div>
          <div className="font-mono text-[10px] font-semibold text-white mt-0.5">COMPLETED</div>
        </div>
        <div className="bg-white/5 rounded px-2 py-1 border border-white/5">
          <div className="font-mono text-[7px] text-dim">ORGANISM MASS</div>
          <div className="font-mono text-[10px] font-semibold text-white mt-0.5">
            {host.status === 'emergence' ? '2.4 kg [EXPANDING]' : '1.85 kg'}
          </div>
        </div>
      </div>
    </VeinCard>
  );
}
