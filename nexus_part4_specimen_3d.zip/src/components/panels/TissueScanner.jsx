import { useEffect, useRef, useState } from 'react';
import { VeinCard } from '../ui/VeinCard';
import { Grid } from 'lucide-react';

const SYMBIONT_COLORS = {
  'Coral-Vascular':     '#45D9C4',
  'Mycelial-Neural':    '#B58BFF',
  'Crystalline-Reflex': '#7DD3FC',
  'Vine-Cognitive':     '#86EFAC',
};

export default function TissueScanner({ host }) {
  const canvasRef = useRef(null);
  const color = SYMBIONT_COLORS[host.symbiontType] || '#45D9C4';
  const [telemetry, setTelemetry] = useState({
    depth: 12.4,
    fibrosis: 3.2,
    density: 88,
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let animId;

    const W = (canvas.width = canvas.offsetWidth);
    const H = (canvas.height = canvas.offsetHeight);

    const particles = [];
    const particleCount = 20;

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * W,
        y: Math.random() * H,
        r: 3 + Math.random() * 6,
        color: Math.random() > 0.6 ? color : 'rgba(242,251,250,0.15)',
        alpha: 0.1 + Math.random() * 0.5,
      });
    }

    const render = () => {
      ctx.clearRect(0, 0, W, H);

      // Grid background
      ctx.strokeStyle = 'rgba(69, 217, 196, 0.02)';
      ctx.lineWidth = 1;
      const size = 15;
      for (let x = 0; x < W; x += size) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
      }
      for (let y = 0; y < H; y += size) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
      }

      // Draw Tissue cells (Host layer at bottom, Symbiont at top)
      // Host cells (calm hex-style circles)
      ctx.strokeStyle = 'rgba(69, 217, 196, 0.08)';
      ctx.fillStyle = 'rgba(69, 217, 196, 0.02)';
      ctx.lineWidth = 1;
      for (let x = 20; x < W; x += 30) {
        for (let y = H - 30; y < H; y += 20) {
          ctx.beginPath();
          ctx.arc(x + (y % 40 === 0 ? 10 : 0), y, 8, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
        }
      }

      // Integration border line (wavy)
      ctx.strokeStyle = 'rgba(242,251,250,0.2)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(0, H / 2);
      for (let x = 0; x <= W; x += 10) {
        const offset = Math.sin(x * 0.05 + Date.now() * 0.002) * 5;
        ctx.lineTo(x, H / 2 + offset);
      }
      ctx.stroke();

      // Symbiont fibers (vines/branches creeping from top to bottom)
      ctx.strokeStyle = color + '66';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let x = 30; x < W; x += 60) {
        ctx.moveTo(x, 0);
        ctx.bezierCurveTo(
          x - 10, H * 0.2,
          x + 20, H * 0.35,
          x + Math.sin(Date.now() * 0.0015 + x) * 8, H / 2
        );
      }
      ctx.stroke();

      // Draw floating lipid particles
      particles.forEach(p => {
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1.0;
      });

      // Animated laser scanning bar sweeping vertically
      const laserY = (Date.now() * 0.05) % (H + 40) - 20;
      ctx.strokeStyle = '#45D9C4';
      ctx.lineWidth = 1.5;
      ctx.shadowBlur = 8;
      ctx.shadowColor = '#45D9C4';
      ctx.beginPath();
      ctx.moveTo(0, laserY);
      ctx.lineTo(W, laserY);
      ctx.stroke();
      ctx.shadowBlur = 0;

      animId = requestAnimationFrame(render);
    };

    render();

    return () => cancelAnimationFrame(animId);
  }, [color]);

  // Minor fluctuations
  useEffect(() => {
    const interval = setInterval(() => {
      setTelemetry(prev => ({
        depth: Math.max(5, Math.min(30, prev.depth + (Math.random() - 0.5) * 0.2)),
        fibrosis: Math.max(1, Math.min(15, prev.fibrosis + (Math.random() - 0.5) * 0.1)),
        density: Math.max(60, Math.min(100, prev.density + Math.round((Math.random() - 0.5) * 1.5))),
      }));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <VeinCard status={host.status} className="p-6 flex flex-col justify-between" style={{ height: '170px', padding: '24px' }}>
      <div className="flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-2">
          <Grid size={14} color={color} />
          <span className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase">
            HISTOLOGICAL SCAN // TISSUE BIOPHY
          </span>
        </div>
        <span className="font-mono text-[8px] text-dim">
          SCANRATE: 60FPS // LAYER-2
        </span>
      </div>

      {/* Live Canvas Area */}
      <div className="flex-1 rounded-lg overflow-hidden bg-black/40 border border-white/5 my-2 relative">
        <canvas ref={canvasRef} className="w-full h-full block" />
        <div className="absolute top-2 left-2 font-mono text-[7px] text-dim pointer-events-none">
          ZONE: CORTEX-SUB-T
        </div>
      </div>

      {/* Histology stats footer */}
      <div className="grid grid-cols-3 gap-2 flex-shrink-0">
        {[
          { label: 'FUSION DEPTH', val: telemetry.depth.toFixed(1) + ' mm' },
          { label: 'FIBROSIS LEVEL', val: telemetry.fibrosis.toFixed(1) + '%' },
          { label: 'CELLULAR DENSITY', val: telemetry.density + '%' },
        ].map((item, i) => (
          <div key={i} className="bg-white/5 rounded p-1.5 border border-white/5 text-center">
            <div className="font-mono text-[7px] text-dim">{item.label}</div>
            <div className="font-mono text-[10px] font-semibold text-white mt-0.5">{item.val}</div>
          </div>
        ))}
      </div>
    </VeinCard>
  );
}
