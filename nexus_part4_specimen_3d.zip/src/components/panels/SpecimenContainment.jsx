import { useEffect, useRef, useState } from 'react';
import { VeinCard } from '../ui/VeinCard';
import { motion } from 'framer-motion';
import { FlaskConical } from 'lucide-react';

export default function SpecimenContainment({ host }) {
  const canvasRef = useRef(null);
  const [telemetry, setTelemetry] = useState({
    density: 45.2,
    motility: 24.8,
    mutation: 0.05,
    ph: 7.35,
  });

  // Telemetry fluctuation
  useEffect(() => {
    const interval = setInterval(() => {
      setTelemetry(prev => {
        const factor = host.status === 'emergence' ? 2.5 : host.status === 'critical' ? 1.8 : 0.5;
        return {
          density: Math.max(10, Math.min(100, prev.density + (Math.random() - 0.5) * factor)),
          motility: Math.max(5, Math.min(100, prev.motility + (Math.random() - 0.5) * factor * 2)),
          mutation: host.status === 'emergence' 
            ? Math.max(1.5, Math.min(10, prev.mutation + (Math.random() - 0.4) * 0.15))
            : host.status === 'critical' 
            ? Math.max(0.5, Math.min(5, prev.mutation + (Math.random() - 0.45) * 0.08))
            : Math.max(0.01, Math.min(0.8, prev.mutation + (Math.random() - 0.5) * 0.01)),
          ph: Math.max(6.2, Math.min(8.5, prev.ph + (Math.random() - 0.5) * 0.02 * factor)),
        };
      });
    }, 1500);
    return () => clearInterval(interval);
  }, [host.status]);

  // Canvas Cell Particle Simulation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let animationId;

    let width = (canvas.width = canvas.offsetWidth);
    let height = (canvas.height = canvas.offsetHeight);

    // Re-adjust size on window resize
    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
    };
    window.addEventListener('resize', handleResize);

    const cells = [];
    const cellCount = host.status === 'emergence' ? 22 : host.status === 'critical' ? 12 : 16;

    // Build initial cells
    for (let i = 0; i < cellCount; i++) {
      cells.push({
        x: Math.random() * width,
        y: Math.random() * height,
        r: 6 + Math.random() * 12,
        vx: (Math.random() - 0.5) * 0.8,
        vy: (Math.random() - 0.5) * 0.8,
        pulseSpeed: 0.02 + Math.random() * 0.03,
        pulseOffset: Math.random() * Math.PI * 2,
        color: host.status === 'emergence' ? '#B58BFF' : host.status === 'critical' ? '#EF4444' : host.status === 'watch' ? '#F59E0B' : '#45D9C4',
        type: Math.random() > 0.5 ? 'host-cell' : 'symbiont-nucleus',
      });
    }

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw background grid lines (advanced laboratory telemetry aesthetic)
      ctx.strokeStyle = 'rgba(69, 217, 196, 0.03)';
      ctx.lineWidth = 1;
      const gridSize = 25;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Draw circular scanner overlay boundary
      const cx = width / 2;
      const cy = height / 2;
      const maxR = Math.min(width, height) * 0.44;

      ctx.strokeStyle = 'rgba(69, 217, 196, 0.08)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(cx, cy, maxR, 0, Math.PI * 2);
      ctx.stroke();

      // Outer ticker line
      ctx.strokeStyle = host.status === 'emergence' ? 'rgba(181, 139, 255, 0.15)' : 'rgba(69, 217, 196, 0.15)';
      ctx.setLineDash([8, 12]);
      ctx.beginPath();
      ctx.arc(cx, cy, maxR + 8, Date.now() * 0.0005, Date.now() * 0.0005 + Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      // Update and draw cells
      const speedMultiplier = host.status === 'emergence' ? 2.8 : host.status === 'critical' ? 1.6 : host.status === 'watch' ? 1.1 : 0.6;
      const pulseMultiplier = host.status === 'emergence' ? 3.0 : 1.0;

      cells.forEach(cell => {
        cell.x += cell.vx * speedMultiplier;
        cell.y += cell.vy * speedMultiplier;

        // Containment wall check (circular constraint)
        const dx = cell.x - cx;
        const dy = cell.y - cy;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist + cell.r > maxR) {
          const angle = Math.atan2(dy, dx);
          cell.x = cx + Math.cos(angle) * (maxR - cell.r);
          cell.y = cy + Math.sin(angle) * (maxR - cell.r);
          // Bounce velocities
          const nx = Math.cos(angle);
          const ny = Math.sin(angle);
          const dot = cell.vx * nx + cell.vy * ny;
          cell.vx -= 2 * dot * nx;
          cell.vy -= 2 * dot * ny;
        }

        // Pulse size
        const currentR = cell.r + Math.sin(Date.now() * cell.pulseSpeed * pulseMultiplier + cell.pulseOffset) * 2;

        ctx.shadowBlur = host.status === 'emergence' ? 12 : 8;
        ctx.shadowColor = cell.color;

        // Draw organism cells
        ctx.fillStyle = cell.color + '22';
        ctx.strokeStyle = cell.color + '99';
        ctx.lineWidth = 1.5;

        if (cell.type === 'host-cell') {
          // Organic amorphous blob
          ctx.beginPath();
          const points = 6;
          for (let p = 0; p < points; p++) {
            const angle = (p / points) * Math.PI * 2;
            const wobble = Math.sin(Date.now() * 0.002 + p * 1.5) * 1.5;
            const px = cell.x + Math.cos(angle) * (currentR + wobble);
            const py = cell.y + Math.sin(angle) * (currentR + wobble);
            if (p === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
          }
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        } else {
          // Cellular nucleus with micro tendrils
          ctx.beginPath();
          ctx.arc(cell.x, cell.y, currentR, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();

          // Core nucleus
          ctx.fillStyle = cell.color;
          ctx.beginPath();
          ctx.arc(cell.x, cell.y, currentR * 0.35, 0, Math.PI * 2);
          ctx.fill();
        }

        // Draw links between nearby symbiont cells if emergence
        if (host.status === 'emergence' || host.status === 'watch') {
          cells.forEach(other => {
            if (cell !== other) {
              const odx = other.x - cell.x;
              const ody = other.y - cell.y;
              const odist = Math.sqrt(odx * odx + ody * ody);
              if (odist < 50) {
                ctx.strokeStyle = cell.color + '25';
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(cell.x, cell.y);
                ctx.lineTo(other.x, other.y);
                ctx.stroke();
              }
            }
          });
        }
      });

      // Reset shadow
      ctx.shadowBlur = 0;

      // Scanning HUD elements (crosshairs)
      ctx.strokeStyle = 'rgba(69, 217, 196, 0.2)';
      ctx.lineWidth = 0.8;
      ctx.beginPath();
      ctx.moveTo(cx - 15, cy); ctx.lineTo(cx + 15, cy);
      ctx.moveTo(cx, cy - 15); ctx.lineTo(cx, cy + 15);
      ctx.stroke();

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, [host.status, host.id]);

  const primaryColor = host.status === 'emergence' ? 'var(--color-alert)' 
    : host.status === 'critical' ? 'var(--color-critical)' 
    : host.status === 'watch' ? 'var(--color-watch)' 
    : 'var(--color-stable)';

  return (
    <VeinCard status={host.status} className="flex flex-col p-6 relative" style={{ height: '315px', padding: '24px' }}>
      {/* HUD Header */}
      <div className="flex items-center justify-between mb-2 flex-shrink-0">
        <div className="flex items-center gap-2">
          <FlaskConical size={14} color={primaryColor} />
          <span className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase">
            CYTOLOGICAL CHAMBER TELEMETRY // POD-04
          </span>
        </div>
        <span className="font-mono text-[9px] text-dim">
          MAGNIFICATION: 400X // LIVE FEED
        </span>
      </div>

      {/* Visual Simulation Containment Chamber */}
      <div className="flex-1 relative rounded-lg overflow-hidden bg-black/40 border border-white/5">
        <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
        
        {/* Absolute Lab Telemetry Overlays */}
        <div className="absolute top-2 left-3 font-mono text-[8px] text-dim flex flex-col gap-1 pointer-events-none">
          <div>REC ID: 99421-E</div>
          <div>HOST SYNC: ACTIVE</div>
        </div>

        <div className="absolute bottom-2 right-3 font-mono text-[8px] text-dim pointer-events-none text-right">
          <div>SECTOR: BIO-RADIAL-B</div>
          <div>TEMP: 37.1°C</div>
        </div>
      </div>

      {/* Quick Scientific Telemetry Stats Footer */}
      <div className="grid grid-cols-4 gap-2 mt-3 flex-shrink-0">
        {[
          { label: 'CELL DENSITY', val: telemetry.density.toFixed(1) + '%', col: 'text-white' },
          { label: 'MOTILITY RATE', val: telemetry.motility.toFixed(1) + '%', col: 'text-white' },
          { label: 'MUTATION RATE', val: telemetry.mutation.toFixed(2) + ' index', col: host.status === 'emergence' ? 'text-alert' : 'text-white' },
          { label: 'PH BALANCE', val: telemetry.ph.toFixed(2), col: 'text-white' },
        ].map((stat, i) => (
          <div key={i} className="bg-white/5 rounded p-2 border border-white/5">
            <div className="font-mono text-[7px] text-dim tracking-tight">{stat.label}</div>
            <div className={`font-mono text-[11px] font-semibold mt-0.5 ${stat.col}`}>{stat.val}</div>
          </div>
        ))}
      </div>
    </VeinCard>
  );
}
