// GenomeMap.jsx — D3 force-directed node graph, per-symbiont visual style
import { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { VeinCard } from '../ui/VeinCard';

const TYPE_STYLES = {
  'Coral-Vascular':     { nodeColor: '#45D9C4', shape: 'circle',   glow: 'rgba(69,217,196,0.6)'  },
  'Mycelial-Neural':    { nodeColor: '#B58BFF', shape: 'star',     glow: 'rgba(181,139,255,0.6)' },
  'Crystalline-Reflex': { nodeColor: '#7DD3FC', shape: 'diamond',  glow: 'rgba(125,211,252,0.6)' },
  'Vine-Cognitive':     { nodeColor: '#86EFAC', shape: 'teardrop', glow: 'rgba(134,239,172,0.6)' },
};

function starPath(r) {
  const pts = 6;
  const inner = r * 0.45;
  let d = '';
  for (let i = 0; i < pts * 2; i++) {
    const angle = (Math.PI / pts) * i - Math.PI / 2;
    const radius = i % 2 === 0 ? r : inner;
    const x = Math.cos(angle) * radius;
    const y = Math.sin(angle) * radius;
    d += (i === 0 ? 'M' : 'L') + `${x},${y}`;
  }
  return d + 'Z';
}

function diamondPath(r) {
  return `M0,${-r} L${r * 0.6},0 L0,${r} L${-r * 0.6},0 Z`;
}

function teardropPath(r) {
  return `M0,${-r} C${r},${-r * 0.3} ${r * 0.8},${r * 0.6} 0,${r} C${-r * 0.8},${r * 0.6} ${-r},${-r * 0.3} 0,${-r} Z`;
}

export function GenomeMap({ host }) {
  const svgRef = useRef(null);
  const style = TYPE_STYLES[host.symbiontType];

  useEffect(() => {
    const container = svgRef.current;
    if (!container) return;

    const W = container.clientWidth || 460;
    const H = container.clientHeight || 260;

    d3.select(container).selectAll('*').remove();

    const svg = d3.select(container)
      .attr('width', W)
      .attr('height', H);

    // Defs: glow filters
    const defs = svg.append('defs');
    const stableFilter = defs.append('filter').attr('id', `glow-stable-${host.id}`);
    stableFilter.append('feGaussianBlur').attr('stdDeviation', 3).attr('result', 'blur');
    stableFilter.append('feMerge').selectAll('feMergeNode').data(['blur', 'SourceGraphic']).enter().append('feMergeNode').attr('in', d => d);

    const alertFilter = defs.append('filter').attr('id', `glow-alert-${host.id}`);
    alertFilter.append('feGaussianBlur').attr('stdDeviation', 4).attr('result', 'blur');
    alertFilter.append('feMerge').selectAll('feMergeNode').data(['blur', 'SourceGraphic']).enter().append('feMergeNode').attr('in', d => d);

    // Zoom layer
    const g = svg.append('g');
    svg.call(
      d3.zoom()
        .scaleExtent([0.4, 3])
        .on('zoom', e => g.attr('transform', e.transform))
    );

    // Build simulation data
    const nodes = host.genomeNodes.map(n => ({ ...n, x: n.x * (W / 500), y: n.y * (H / 340) }));
    const links = [];
    nodes.forEach(n => {
      n.connections.forEach(targetId => {
        const target = nodes.find(x => x.id === targetId);
        if (target) links.push({ source: n, target });
      });
    });

    // Simulation
    const sim = d3.forceSimulation(nodes)
      .force('link', d3.forceLink(links).id(d => d.id).distance(70).strength(0.4))
      .force('charge', d3.forceManyBody().strength(-120))
      .force('center', d3.forceCenter(W / 2, H / 2))
      .force('collision', d3.forceCollide(24));

    // Links
    const linkSel = g.append('g').selectAll('line')
      .data(links).enter().append('line')
      .attr('stroke', style.nodeColor)
      .attr('stroke-opacity', 0.25)
      .attr('stroke-width', 1.2)
      .attr('stroke-dasharray', '5 3');

    // Nodes
    const nodeGroup = g.append('g').selectAll('g')
      .data(nodes).enter().append('g')
      .attr('cursor', 'grab')
      .call(
        d3.drag()
          .on('start', (e, d) => { if (!e.active) sim.alphaTarget(0.3).restart(); d.fx = d.x; d.fy = d.y; })
          .on('drag',  (e, d) => { d.fx = e.x; d.fy = e.y; })
          .on('end',   (e, d) => { if (!e.active) sim.alphaTarget(0); d.fx = null; d.fy = null; })
      );

    const r = 10;

    nodeGroup.each(function(d) {
      const el = d3.select(this);
      const nodeColor = d.stable ? style.nodeColor : '#B58BFF';
      const filterId = d.stable ? `glow-stable-${host.id}` : `glow-alert-${host.id}`;

      switch (host.symbiontType) {
        case 'Coral-Vascular':
          // Circle with wavy outer ring
          el.append('circle').attr('r', r + 5).attr('fill', 'none')
            .attr('stroke', nodeColor).attr('stroke-opacity', 0.2).attr('stroke-width', 1.5)
            .attr('stroke-dasharray', '3 2');
          el.append('circle').attr('r', r).attr('fill', `${nodeColor}22`)
            .attr('stroke', nodeColor).attr('stroke-width', 1.5)
            .attr('filter', `url(#${filterId})`);
          break;

        case 'Mycelial-Neural':
          // Star + thin radiating lines
          for (let i = 0; i < 6; i++) {
            const angle = (Math.PI * 2 / 6) * i;
            el.append('line')
              .attr('x1', 0).attr('y1', 0)
              .attr('x2', Math.cos(angle) * (r + 8)).attr('y2', Math.sin(angle) * (r + 8))
              .attr('stroke', nodeColor).attr('stroke-opacity', 0.2).attr('stroke-width', 0.8);
          }
          el.append('path').attr('d', starPath(r))
            .attr('fill', `${nodeColor}22`).attr('stroke', nodeColor).attr('stroke-width', 1.5)
            .attr('filter', `url(#${filterId})`);
          break;

        case 'Crystalline-Reflex':
          el.append('path').attr('d', diamondPath(r + 2))
            .attr('fill', 'none').attr('stroke', nodeColor).attr('stroke-opacity', 0.2).attr('stroke-width', 1);
          el.append('path').attr('d', diamondPath(r))
            .attr('fill', `${nodeColor}22`).attr('stroke', nodeColor).attr('stroke-width', 1.5)
            .attr('filter', `url(#${filterId})`);
          break;

        case 'Vine-Cognitive':
          el.append('path').attr('d', teardropPath(r))
            .attr('fill', `${nodeColor}22`).attr('stroke', nodeColor).attr('stroke-width', 1.5)
            .attr('filter', `url(#${filterId})`);
          // Curling tendril
          el.append('path').attr('d', `M0,${r} C${r * 1.5},${r * 1.8} ${r * 2},${r * 0.5} ${r * 1.5},0`)
            .attr('fill', 'none').attr('stroke', nodeColor).attr('stroke-opacity', 0.25).attr('stroke-width', 1);
          break;

        default:
          el.append('circle').attr('r', r).attr('fill', `${nodeColor}22`)
            .attr('stroke', nodeColor).attr('stroke-width', 1.5);
      }

      // Label
      el.append('text')
        .attr('dy', r + 14)
        .attr('text-anchor', 'middle')
        .attr('font-family', 'var(--font-mono)')
        .attr('font-size', 8)
        .attr('fill', d.stable ? 'rgba(242,251,250,0.5)' : '#B58BFF')
        .text(d.label);
    });

    // Tick
    sim.on('tick', () => {
      linkSel
        .attr('x1', d => d.source.x).attr('y1', d => d.source.y)
        .attr('x2', d => d.target.x).attr('y2', d => d.target.y);
      nodeGroup.attr('transform', d => `translate(${d.x},${d.y})`);
    });

    // Animate vein-pulse on links
    linkSel.append('animate')
      .attr('attributeName', 'stroke-opacity')
      .attr('values', '0.15;0.45;0.15')
      .attr('dur', '3s')
      .attr('repeatCount', 'indefinite');

    return () => sim.stop();
  }, [host.id, host.symbiontType, host.status]);

  return (
    <VeinCard status={host.status} style={{ padding: '24px', flex: 1 }}>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--color-text-muted)', letterSpacing: '0.1em', marginBottom: '8px' }}>
        MUTAGENIC CHROMOSOME NETWORK
        <span style={{ marginLeft: '8px', fontSize: '9px', color: 'var(--color-text-dim)' }}>drag · scroll to zoom</span>
      </div>
      <div style={{ background: 'rgba(0,0,0,0.2)', borderRadius: '8px', overflow: 'hidden', height: '260px' }}>
        <svg ref={svgRef} style={{ width: '100%', height: '100%', display: 'block' }} />
      </div>
    </VeinCard>
  );
}
